import React from 'react'

export default function({ children }) {
  return <ol className="piano__scale">{children}</ol>
}
